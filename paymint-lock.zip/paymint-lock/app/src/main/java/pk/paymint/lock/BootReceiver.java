package pk.paymint.lock;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restart monitoring after reboot. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            if (Locker.isDeviceOwner(context)) Locker.applyOwnerPolicies(context);
            if (Locker.isAdminActive(context) || Locker.isDeviceOwner(context)) {
                PollService.start(context);
            }
        }
    }
}
