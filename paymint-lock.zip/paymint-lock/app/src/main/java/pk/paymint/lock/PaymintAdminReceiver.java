package pk.paymint.lock;

import android.app.admin.DeviceAdminReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

/** Device admin receiver. Being device admin lets the app lock the screen. */
public class PaymintAdminReceiver extends DeviceAdminReceiver {

    public static ComponentName getComponent(Context c) {
        return new ComponentName(c.getApplicationContext(), PaymintAdminReceiver.class);
    }

    @Override
    public void onEnabled(Context context, Intent intent) {
        super.onEnabled(context, intent);
        // If we are Device Owner, apply the stronger EMI lockdown.
        Locker.applyOwnerPolicies(context);
        // Start monitoring once admin is granted.
        PollService.start(context);
    }
}
