package pk.paymint.lock;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Customer home: shows the installments / payment screen (the server's /me page) inside the app,
 * so the customer has ONE app for everything. A small "Setup" button opens the device-owner
 * setup/consent screen used by the shopkeeper at provisioning. The lock service runs in the
 * background regardless.
 */
public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0B1220"));

        // top bar
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int pad = dp(10);
        bar.setPadding(dp(14), pad, dp(10), pad);
        bar.setBackgroundColor(Color.parseColor("#141F33"));

        TextView title = new TextView(this);
        title.setText("Paymint");
        title.setTextColor(Color.parseColor("#12D6A0"));
        title.setTextSize(19);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bar.addView(title, tlp);

        Button setup = new Button(this);
        setup.setText("Setup");
        setup.setOnClickListener(v -> startActivity(new Intent(this, SetupActivity.class)));
        bar.addView(setup);

        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // webview
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);           // /me uses localStorage for token + language
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onReceivedError(WebView v, int code, String desc, String url) {
                v.loadData("<html><body style='background:#0B1220;color:#93A4BF;font-family:sans-serif;padding:24px;text-align:center'>"
                        + "<h3 style='color:#12D6A0'>Paymint</h3><p>Internet nahi mil raha. Please check your connection and reopen the app.</p></body></html>",
                        "text/html", "utf-8");
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        web.loadUrl(Api.baseUrl(this) + "/me");

        // keep the lock monitor running if protection is set up
        if (Locker.isDeviceOwner(this)) Locker.applyOwnerPolicies(this);
        if (Locker.isAdminActive(this) || Locker.isDeviceOwner(this)) PollService.start(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.reload();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
}
