package pk.paymint.lock;

import android.app.admin.DevicePolicyManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Setup + consent screen (device code, consent, enable protection). Used by the shopkeeper at provisioning. */
public class SetupActivity extends Activity {

    private static final int REQ_ADMIN = 101;
    private EditText urlInput;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        setContentView(buildUi());
        refreshStatus();
        // If already set up, apply owner lockdown (if owner) and keep the monitor running.
        if (Locker.isDeviceOwner(this)) Locker.applyOwnerPolicies(this);
        if (Locker.isAdminActive(this) || Locker.isDeviceOwner(this)) PollService.start(this);
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(22);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.parseColor("#0B1220"));
        sv.addView(root);

        TextView brand = new TextView(this);
        brand.setText("Paymint");
        brand.setTextColor(Color.parseColor("#12D6A0"));
        brand.setTextSize(30);
        root.addView(brand);

        TextView sub = new TextView(this);
        sub.setText("Installment plan protection");
        sub.setTextColor(Color.parseColor("#93A4BF"));
        sub.setPadding(0, 0, 0, dp(18));
        root.addView(sub);

        // Device code
        root.addView(label("Your device code"));
        TextView code = new TextView(this);
        code.setText(Api.deviceId(this));
        code.setTextColor(Color.WHITE);
        code.setTextSize(20);
        code.setPadding(0, dp(2), 0, dp(4));
        root.addView(code);
        TextView codeHint = new TextView(this);
        codeHint.setText("Give this code to the shop so they can link it to your installment plan.");
        codeHint.setTextColor(Color.parseColor("#93A4BF"));
        codeHint.setTextSize(13);
        codeHint.setPadding(0, 0, 0, dp(16));
        root.addView(codeHint);

        // Backend URL
        root.addView(label("Paymint server address"));
        urlInput = new EditText(this);
        urlInput.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setText(Api.baseUrl(this));
        urlInput.setTextColor(Color.WHITE);
        root.addView(urlInput);
        Button save = new Button(this);
        save.setText("Save server address");
        save.setOnClickListener(v -> {
            Api.setBaseUrl(this, urlInput.getText().toString().trim());
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        });
        root.addView(save);

        // Consent
        TextView consent = new TextView(this);
        consent.setText("\nBy enabling protection you agree that, as part of your installment plan, Paymint may lock this device if a payment becomes overdue. Emergency calls remain available at all times, and the device unlocks automatically once your payment is confirmed. The device is fully yours once all installments are paid.");
        consent.setTextColor(Color.parseColor("#C7D4E6"));
        consent.setTextSize(14);
        consent.setPadding(0, dp(14), 0, dp(10));
        root.addView(consent);

        final CheckBox agree = new CheckBox(this);
        agree.setText("I understand and agree");
        agree.setTextColor(Color.WHITE);
        root.addView(agree);

        Button enable = new Button(this);
        enable.setText("Enable protection");
        enable.setOnClickListener(v -> {
            if (!agree.isChecked()) { Toast.makeText(this, "Please agree first", Toast.LENGTH_SHORT).show(); return; }
            requestAdmin();
        });
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ep.topMargin = dp(12);
        root.addView(enable, ep);

        status = new TextView(this);
        status.setTextColor(Color.parseColor("#93A4BF"));
        status.setPadding(0, dp(18), 0, 0);
        root.addView(status);

        return sv;
    }

    private void requestAdmin() {
        if (Locker.isAdminActive(this)) {
            PollService.start(this);
            Toast.makeText(this, "Protection already active", Toast.LENGTH_SHORT).show();
            refreshStatus();
            return;
        }
        Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, PaymintAdminReceiver.getComponent(this));
        i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.admin_description));
        startActivityForResult(i, REQ_ADMIN);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_ADMIN) {
            if (Locker.isAdminActive(this)) {
                PollService.start(this);
                Toast.makeText(this, "Protection enabled", Toast.LENGTH_SHORT).show();
            }
            refreshStatus();
        }
    }

    private void refreshStatus() {
        String admin = Locker.isAdminActive(this) ? "active" : "not enabled";
        String owner = Locker.isDeviceOwner(this) ? " · device owner" : "";
        status.setText("Protection: " + admin + owner + "\nDevice code: " + Api.deviceId(this));
    }

    private TextView label(String t) {
        TextView l = new TextView(this);
        l.setText(t);
        l.setTextColor(Color.parseColor("#93A4BF"));
        l.setTextSize(13);
        l.setPadding(0, dp(8), 0, dp(4));
        return l;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
}
