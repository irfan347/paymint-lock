package pk.paymint.lock;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.UUID;

/** Tiny HTTP helper that talks to the Paymint backend. No third-party libraries. */
public class Api {
    public static final String PREFS = "paymint";
    public static final String KEY_BASE = "base_url";
    public static final String KEY_DEVICE = "device_id";

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** A stable device id generated once and kept locally. */
    public static String deviceId(Context c) {
        SharedPreferences p = prefs(c);
        String id = p.getString(KEY_DEVICE, null);
        if (id == null) {
            id = "PM-" + UUID.randomUUID().toString().substring(0, 12).toUpperCase();
            p.edit().putString(KEY_DEVICE, id).apply();
        }
        return id;
    }

    public static String baseUrl(Context c) {
        return prefs(c).getString(KEY_BASE, BuildConfig.DEFAULT_BASE_URL).replaceAll("/+$", "");
    }

    public static void setBaseUrl(Context c, String url) {
        prefs(c).edit().putString(KEY_BASE, url).apply();
    }

    /** Result of a status poll. */
    public static class Status {
        public boolean ok;        // request succeeded
        public boolean locked;    // backend says device should be locked
        public boolean registered;// device is linked to a customer
        public String message = "";
    }

    /** GET /api/device/status?device_id=... */
    public static Status checkStatus(Context c) {
        Status s = new Status();
        HttpURLConnection conn = null;
        try {
            String url = baseUrl(c) + "/api/device/status?device_id="
                    + URLEncoder.encode(deviceId(c), "UTF-8");
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            conn.setRequestMethod("GET");
            int code = conn.getResponseCode();
            String body = read(conn, code >= 400);
            JSONObject j = new JSONObject(body);
            if (code == 200) {
                s.ok = true;
                s.registered = true;
                s.locked = j.optBoolean("locked", false);
                s.message = j.optString("message", "");
            } else if (code == 404) {
                // device not registered yet — do not lock
                s.ok = true;
                s.registered = false;
                s.locked = false;
            } else {
                s.ok = false;
            }
        } catch (Exception e) {
            s.ok = false; // network error — fail safe: do not lock
        } finally {
            if (conn != null) conn.disconnect();
        }
        return s;
    }

    private static String read(HttpURLConnection conn, boolean err) throws Exception {
        StringBuilder sb = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(
                err ? conn.getErrorStream() : conn.getInputStream()));
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }
}
