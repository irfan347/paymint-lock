# Paymint Lock — Android app

The device-side app for Paymint installment financing. It checks the Paymint backend and, **with the
customer's consent**, locks the phone while an installment is overdue. The phone unlocks automatically
once the payment is confirmed, and is fully the customer's once all installments are paid. Emergency
calls remain available at all times.

This is built the legitimate, transparent way — modeled on how device financing works (e.g. Google's
own [Android Device Lock Controller](https://source.android.com/docs/core/admin/device-lock)). It is
**not** hidden or stealth: the customer sees a clear consent screen before enabling it.

## One app does everything

The app is both the **customer app** and the **lock enforcer**:

- Opening it shows the customer's **installments / payment screen** (the server's `/me` page, loaded in a
  WebView) — they log in with phone + PIN, see paid/remaining, pay via JazzCash/Easypaisa, and get receipts.
- A small **Setup** button (top-right) opens the device-owner setup/consent screen — the shopkeeper uses
  this once, at provisioning, to show the device code and enable protection.
- In the background a service enforces the lock when a payment is overdue.

So the customer has just **one app** for everything, PalmPay-style.

## How the lock fits together

1. At setup, the app shows a **device code** (e.g. `PM-ABC123...`) on the Setup screen; the customer consents.
2. The shopkeeper opens that customer in the Paymint panel → **Link device** → enters the code.
3. The app polls `GET /api/device/status?device_id=...` every minute.
   - If the backend says `locked: true` (an installment is overdue) → a full-screen lock notice appears.
   - When the payment is confirmed → `locked: false` → the device unlocks automatically.

The app never decides to lock on its own — the backend does, based only on overdue installments.
On any network error it **fails safe** (does not lock).

**What "locked" blocks (Device Owner mode):** while locked, the app pins the phone to the full-screen
lock notice (kiosk) and disables the status bar/notifications, so the customer can't open the dialer,
browser or any app — meaning calls and mobile data can't be used. It also disables outgoing calls and
SMS by policy. **Emergency calls remain available.** Everything is restored automatically the moment
the payment is confirmed. In the simpler Device Admin mode (no Device Owner), the lock notice shows but
these hard call/data blocks don't apply.

**Security hardening (Device Owner, always on):** the app blocks factory reset, safe boot, USB
debugging/ADB, installing or uninstalling apps, force-stopping or clearing the app's data, VPNs,
tethering, USB file transfer, changing the device clock, and adding new users. This closes the common
bypass routes. **Note:** no software lock is 100% reset-proof — a technically skilled person with an
unlocked bootloader and flashing tools can still wipe any Android device (true of every EMI lock).
Keep the bootloader locked and OEM unlocking off for the strongest protection.

## Build the APK (GitHub Actions)

Push this folder to a GitHub repo. The workflow in `.github/workflows/android.yml` builds it:

- Go to the repo → **Actions** → **Build APK** → it runs on each push to `main`, or run it manually
  ("Run workflow").
- When it finishes, open the run → **Artifacts** → download **paymint-lock-debug-apk**.

Before building, set your server address in `app/build.gradle`:

```gradle
buildConfigField "String", "DEFAULT_BASE_URL", "\"https://your-paymint.onrender.com\""
```

(The customer can also change it on the app's first screen.)

## Installing it on a phone

The app works in two modes:

**A. Device Admin (simple — sideload on any phone)**
Install the APK, open it, agree to the consent, tap **Enable protection**, and approve the device-admin
request. This lets the app show the lock notice and trigger the keyguard. Good for testing and basic use.

**B. Device Owner (proper EMI lock — recommended for financed phones)**
Device Owner makes the lock un-bypassable. When the app is Device Owner it also blocks factory reset,
safe boot, and uninstalling the app, and can pin the lock screen. It is set **once**, on a **new or
factory-reset phone, before any Google account is added**. There are two ways:

**Method 1 — ADB (needs a computer + USB cable, one time).** Simplest if you can borrow a computer:
1. On the fresh phone, do not add any Google account. Enable Developer Options → USB debugging.
2. On the computer (with Android platform-tools installed):
   ```
   adb install app-debug.apk
   adb shell dpm set-device-owner pk.paymint.lock/.PaymintAdminReceiver
   ```
3. Open the app, agree to consent. It's now Device Owner.

**Method 2 — QR provisioning (no computer needed).** Good if you only have phones:
1. Host the built `app-debug.apk` at a public URL (e.g. attach it to a GitHub **Release**, or any
   direct-download link).
2. Get the **signature checksum**: the build uploads a `signature-checksum.txt` next to the APK
   (see the Actions artifact). Copy that value.
3. Use the **Paymint provisioning QR generator** (separate page — link provided by Paymint) and enter
   the APK URL, the checksum, and optional Wi‑Fi. It produces a QR code.
4. On the **fresh / factory-reset** phone, at the very first "Hi there" welcome screen, **tap the same
   spot 6 times** → a QR scanner opens → connect Wi‑Fi → scan your QR. Android downloads the APK and
   sets it as Device Owner automatically.

> Device Owner can only be set on a device with **no accounts** configured. Provision each phone this way
> **before** handing it to the customer. To remove it later (e.g. once fully paid), the app allows it or
> the phone can be factory reset from Device Owner.

## Legal / fair-use

Only use this where the customer has agreed in writing, as part of a real installment plan, that the device
may be locked for non-payment. Always keep emergency calling available (this app does), unlock promptly on
payment, and release the device fully once paid. Do not deploy it on devices you do not finance.
